# These are my notes when working through the examples in the chapter.
# Author: Firstname, Lastname


# Chapter 1 - Crash course R
# A numeric vector
v <- c(1,4,5,6)

# A named list
l <- list(
  element_a = "a",
  number_2 = 2
)

# A data frame (or structured named lists)
df <- data.frame(
  numbers = c(1,3,2),
  letters = c("a", "b","c")
)
# Playing around with these
l[1]
v[2]
v[5] # gives NA back since not defined
df
df[2, "numbers"]





# Chapter 4 - Phenology trends
# Getting the data
# install.packages("geodata") # This needs to be done once.
library(geodata) # This needs to be done in each session (script/markdown file).

# download SRTM data
# This stores file srtm_38_03.tif in
# subfolder elevation of tempdir()
geodata::elevation_3s(
  lat = 46.6756,
  lon = 7.85480,
  path = tempdir()
)
