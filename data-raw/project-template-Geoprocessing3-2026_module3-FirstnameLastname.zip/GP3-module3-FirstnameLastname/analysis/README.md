In a bigger project, I suggest to put code that performs the data analysis in this folder.



In the framework of the Geoprocessing III exercises, I suggest you use R scripts in this folder to understand the code shown in the online book and try out things. To solve the exercises you will hand in a report which is not an R script but an R markdown/quarto file that is best generated in the `./report/` subfolder.