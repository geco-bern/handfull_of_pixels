# The GECO R project template for Geoprocessing III

(this is a simplified template inspired by https://github.com/geco-bern/R_proj_template)

This is a project folder template for a GECO R project repository - specifically for
the Geoprocessing III course. This template can be downloaded and provides a 
project folder with a standard set of directories. 
This ensures a project-oriented and consistent workflow, and removes some of the mental
overhead in making decisions on a project structure.

It must be noted that some of the functionality as provided by this setup is
included in the [`usethis`](https://usethis.r-lib.org/) R package, the aim is 
slightly different. For one, `usethis` is aimed at populating a R package structure.
The template here is for R project work.
Second, there is not preset full template, hence many individual decisions still
need to be made and code executed. This is bypassed by this setup.

## Quickstart

Work through the chapters and exercises that are part of this course.
You hand-in your answers to the exercises with the report in subfolder `./report/`.
In there you develop your answers and code needed for their illustration in the form
of a Quarto notebook.

When working through the chapters I encourage you to try out the presented code.
A good option would be to do this in the R script in the subfolder `./analysis/`.


## Use

### A RStudio project from the template

To use the template download this repo as zip file, unzip, and rename `firstnamelastname`
in the resulting folder and `*.Rproj` files. Then open the `*.Rproj` with RStudio.

## Structure

The structure of the template follows the structure of an R package without
actually being one. There are several reasons for this.

- Familiarizes you with an R package structure
  - allowing for an optional switch to an R package
- Avoids top level aggregation of data, code and reporting files
- Splits the dynamic reporting from academic writing (`vignettes` vs. `manuscript`)
- Splits pre-processing of data from working / included data (`data-raw` vs. `data`)
- Splits R code from other scripts (bash / python in `src`)
- Splits R functions from R analysis scripts (`R` vs `analysis`)

Below you find a comprehensive list of what goes where an why, as well as some
best practices on how to structure further data within these folders.

### The R folder

The `R` folder contains R functions, not scripts. This means code wrapped in a
structure as such

```R
# A demo function
#
# This function demonstrates the general layout
# of a function

my_function <- function(parameter) {
  some_actions
}
```

Functions are actions you need more than once, which can not be generated
easily with external packages and are tailored to your project.

These functions should stand on their own with limited links to additional
custom functions. Ideally you provide a brief title and description on the 
function's purpose before.

Writing functions seems an initial waste of time, you could easily just copy and
paste some code in your analysis scripts. However, this means that if you
decide certain aspects of this workflow you might have to hunt down these
changes in all analysis scripts. Failing to do so will result in corrupted 
analysis. In addition, writing functions will make it easy to re-use the code
within the context of a new project, and if proven to be generally useful
outside a single research project it can be integrated in a formal package.

### The data-raw folder

The `data-raw` folder contains, as the name suggests, raw data and the scripts
to download and pre-process the data. This is data which requires significant
pre-processing to be of use in analysis. In other words, this data is not 
analysis ready (within the context of the project).

To create full transparency in terms of the source of this raw data it is best
to include (numbered) scripts to download and pre-process the data. Either in
these scripts, or in a separate README, include the source of the data (reference)
Ultimately, the output of the workflow in data-raw is data which is analysis ready.

It is best practice to store various raw data products in their own sub-folder,
with data downloading and processing scripts in the main `data-raw` folder.

```
data-raw/
├─ raw_data_product/
├─ 00_download_raw_data.R
├─ 01_process_raw_data.R
```

Where possible it is good practice to store output data (in `data`) either as human 
readable CSV files, or as R serialized files 
(generated using with the `saveRDS()` function).

It is common that raw data is large in size, which limits the option of storing
the data in a git repository. If this isn't possible this data can be excluded
from the git repository by explicitly adding directories to `.gitignore` to
avoid accidentally adding them.

When dealing with heterogeneous systems dynamic paths can be set to (soft) link
to raw-data outside the project directory.

### The data folder

The `data` folder contains analysis ready data. This is data which you can use,
as is. This often contains the output of a `data-raw` pre-processing workflow,
but can also include data which doesn't require any intervention, e.g. a land
cover map which is used as-is. Output from `data-raw` often undergoes a
dramatic dimensionality reduction and will often fit github file size limits. In
some cases however some data products will still be too large, it is recommended
to use similar practices as describe for `data-raw` to ensure transparency
on the sourcing of this data (and reproducible acquisition).

It is best to store data in transparently named sub-folders according to the
product type, once more including references to the source of the data where
possible. Once more, download scripts can be used to ensure this transparency
as well.

```
data/
├─ data_product/
├─ 00_download_data.R
```

### The analysis folder

The `analysis` folder contains, *surprise*, R scripts covering analysis of your
analysis ready data (in the `data` folder). These are R scripts with output
which is limited to numbers, tables and figures. It should not include R
markdown code!

It is often helpful to create additional sub-folders for statistics and figures,
especially if figures are large and complex (i.e. visualizations, rather than
graphical representations of statistical properties, such as maps). 

Scripts can have a numbered prefix to indicate an order of execution, but this
is generally less important as you will work on analysis ready data. If there
is carry over between analysis, either merge the two files or use numbered
prefixes.

```
analysis/
├─ statistics/
│  ├─ 00_random_forest_model.R
│  ├─ 01_random_forest_tuning.R
├─ figures/
│  ├─ global_model_results_map.R
│  ├─ complex_process_visualization.R
```

Output of the analysis routines can be written to file (`report` folder) or
visualized on the console or plot viewer panel.

### The vignettes and report folders

The `vignettes` and `report` folder contains dynamic notebooks, i.e. R markdown or
Quarto files. These might serve a dual use between analysis and manuscript. 
However, the use case in reality should be considered very narrowly. See further 
discussion of this in https://github.com/geco-bern/R_proj_template. 

Here, we use Quarto Notebooks in the framework of an educational example allowing
for a simplified entry into R programming and reporting of results from an exercise
session.

### Capturing your session state (ADVANCED USAGE)

If you want to ensure full reproducibility you will need to capture the state of 
the system and libraries with which you ran the original analysis. Note that you 
will have to execute all code and required libraries for `renv` to correctly 
capture all used libraries.

When setting up your project you can run:

``` r
# Initiate a {renv} environment
renv::init()
```

To initiate your static R environment. Whenever you want to save the state of your project (and its packages) you can call:

``` r
# Save the current state of the environment / project
renv::snapshot()
```

To save any changes made to your environment. All data will be saved in a project description file called a lock file (i.e. `renv.lock`). It is advised to update the state of your project regularly, and in particular before closing a project.

When you move your project to a new system, or share a project on github with collaborators, you can revert to the original state of the analysis by calling:

``` r
# On a new system, or when inheriting a project
# from a collaborator you can use a lock file
# to restore the session/project state using
renv::restore()
```

> NOTE: As mentioned in the {renv} documentation: "For development and collaboration, the `.Rprofile`, `renv.lock` and `renv/activate.R` files should be committed to your version control system. But the `renv/library` directory should normally be ignored. Note that `renv::init()` will attempt to write the requisite ignore statements to the project `.gitignore`." We refer to \@ref(learning-objectives-6) for details on github and its use.

