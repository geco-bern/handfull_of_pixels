Here would be a location to define R functions that your code in `./analysis` or `./report` uses. Functions are a good way to avoid copy pasting code that you need in multiple places or multiple times. 

(In programming, such functions are a way to apply the DRY principle - "Don't Repeat Yourself". Using this principle leads to better, more maintainable code.)