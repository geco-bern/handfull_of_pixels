Answer the exercise questions in your report qmd/Rmd file.

Knit/Render it to HTML to save it in visually appealing report form.